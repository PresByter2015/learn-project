let { createDiffieHellman } = require('crypto');
//客户端
let client = createDiffieHellman(512);
let clientKeys = client.generateKeys();//A

let prime = client.getPrime();//p
let generator = client.getGenerator();//N

//服器端做的事情
let server = createDiffieHellman(prime, generator);
let severKeys = server.generateKeys();// B 

let client_secret = client.computeSecret(severKeys);
let server_secret = server.computeSecret(clientKeys);

console.log(client_secret.toString('hex'), server_secret.toString('hex'));


/**
let N = 23;
let p = 5;
let secret1 = 6;//内部使用，不向外暴露
let A = Math.pow(p, secret1) % N;
console.log('p=', p, 'N=', N, 'A=', A);

let secret2 = 15;
let B = Math.pow(p, secret2) % N;
console.log('p=', p, 'N=', N, 'B=', B);
//A这样计算
console.log(Math.pow(B, secret1) % N);
//B是这样计算的
console.log(Math.pow(A, secret2) % N);
 */