var http = require('http');
http.createServer(function (req, res) {
    let buffer = Buffer.from('hello');//buffer字节组件
    console.log(buffer);
    res.end(buffer);
}).listen(7788, () => console.log('listen 7788'));;
