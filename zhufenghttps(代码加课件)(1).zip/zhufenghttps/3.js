/**
 * 现在实现一个RSA非对称加密算法
 * 加密用的密钥和解密用的密钥不一样
 * 但是它们有关系 ，你不能通过公钥算出密钥
 * 两个质数相成得到一个结果,正向乘很容易 ，但是给你一个乘积，你不知道它们是由哪个数乘出来的
 * p*q=K
 * p*q= K
 *  ffffffffffffff3f323f23333333333333333333333333333333333333333333333333333333
 */
let p = 3, q = 11;
//数学上无法实现从N求出p和q
let N = p * q;//33
let fN = (p - 1) * (q - 1);//欧拉函数
let e = 7;//随意 挑一个指数e 
//{e,N} {7，33} 就成为我们的公钥，公钥 可以发给任何人，是公开的
//公钥和密钥，是一对，公钥 加密的数据要用密钥解密，密钥加密的数据要用公钥来机密
//我们可以从公钥去推算私钥，但是前提是你得知道 fN
//e * d % fN==1 说明就是我们要找的密钥的
for (var d = 1; e * d % fN !== 1; d++) {

}
let publicKey = { e, N };
let privateKey = { d, N };

console.log(d);//d=3

let data = 5;
let c = Math.pow(data, publicKey.e) % publicKey.N;
console.log('c', c);
let original = Math.pow(c, privateKey.d) % privateKey.N;
console.log(original);

