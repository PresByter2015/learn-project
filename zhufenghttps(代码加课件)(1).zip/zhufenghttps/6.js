let crypto = require('crypto');
let content = '123456';
let md5Hash = crypto.createHash('md5').update(content).update(content).digest('hex');
console.log('md5Hash', md5Hash, md5Hash.length);//32
let salt = '123456';
let sha1Hash1 = crypto.createHmac('sha256', salt).update(content).update(content).digest('hex');
console.log('sha1Hash1', sha1Hash1, sha1Hash1.length);//64
let sha1Hash2 = crypto.createHmac('sha256', salt).update(content + content).digest('hex');
console.log('sha1Hash2', sha1Hash2, sha1Hash2.length);//64
let s = [];
s.push(1);
s.push(2);