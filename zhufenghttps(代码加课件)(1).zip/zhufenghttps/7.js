let { generateKeyPairSync, createSign, createVerify } = require('crypto');
/**
 * 数字签名和数据证书实现过程
 */
//生成一对密钥对，一个是公钥，一个私钥
let rsa = generateKeyPairSync('rsa', {
    modulusLength: 1024,
    publicKeyEncoding: {
        type: 'spki',
        format: 'pem'//base64格式的私钥
    },
    privateKeyEncoding: {
        type: 'pkcs8',
        format: 'pem',
        cipher: 'aes-256-cbc',
        passphrase: 'passphrase'//私钥的密码
    }
});
let file = 'file';
//先创建签名对象
let signObj = createSign('RSA-SHA256');
//放入文件内容 
signObj.update(file);
//用rsa私钥签名，输出一个16进制的字符串
let sign = signObj.sign({ key: rsa.privateKey, format: 'pem', passphrase: 'passphrase' }, 'hex');
console.log(sign);
//创建验证签名对象
let verifyObj = createVerify('RSA-SHA256');
//放入文件内容
verifyObj.update(file);
//验证签名是否合法
let isValid = verifyObj.verify(rsa.publicKey, sign, 'hex');
console.log(isValid);
// 内部是这样的实现，我是如何知道签名是否正确呢
// 验证方先拿 到文件file，然后用publicKey计算签名sign,如果跟对方的sign匹配，则验证通过
